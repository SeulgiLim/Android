package kr.go.mapo.in212activitydata

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_second.*

class SecondActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)

        // 현재 액티비티를 실행하기 위해 사용한 인텐트로 부터 데이터를 추출한다.
        val data1 = intent.getIntExtra("data1", 0)
        val data2 = intent.getDoubleExtra("data2", 0.0)
        val data3 = intent.getBooleanExtra("data3", false)
        val data4 = intent.getStringExtra("data4")

        textView2.text = "data1 : ${data1}\n"
        textView2.append("data2 : ${data2}\n")
        textView2.append("data3 : ${data3}\n")
        textView2.append("data4 : ${data4}")


        button2.setOnClickListener {

            // 다른 화면 데이터 전달받아 사용 할 때 - 데이터 전달 받는 부분
            // 현재 Activity가 종료되고 돌아올 때 데이터를 전달해주게 됨


            // SecondActivity 종료할 때
            val result_intent = Intent()            // Intent 객체 생성

            result_intent.putExtra("value1", 200)
            result_intent.putExtra("value2", 22.22)
            result_intent.putExtra("value3", false)
            result_intent.putExtra("value4", "문자열2")


            // Intent Setting
            setResult(Activity.RESULT_OK, result_intent)

            finish()
        }
    }
}