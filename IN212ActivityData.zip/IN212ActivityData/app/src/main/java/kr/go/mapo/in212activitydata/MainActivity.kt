package kr.go.mapo.in212activitydata

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    // StartforResult를 이용해서 SecondActivity를 실행한다.

    val SECOND_ACTIVITY = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button.setOnClickListener {
            // MainActivity에서 SecondActivity로 데이터 전달
            val second_intent = Intent(this, SecondActivity::class.java)

            second_intent.putExtra("data1", 100)
            second_intent.putExtra("data2", 11.11)
            second_intent.putExtra("data3", true)
            second_intent.putExtra("data4", "문자열1")


            // 다른 화면 데이터 전달받아 사용 할 때 - startActivity(second_intent) 삭제
            // startActivity(second_intent)
            startActivityForResult(second_intent, SECOND_ACTIVITY) // requestcode 값 (SECOND_ACTIVITY) 그대로 넘어옴

        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {  //SecondActivity에서 Setting 해 준 Intetn가 3번째 매개변수 (data: Intent?) 들어옴
        super.onActivityResult(requestCode, resultCode, data)

        if(requestCode == SECOND_ACTIVITY){
            if(resultCode == Activity.RESULT_OK){                   // resultCode 꼭 셋팅하고, 분기 해줄 것!!!!!

                // data 뽑기
                val value1 = data?.getIntExtra("value1", 0)
                val value2 = data?.getDoubleExtra("value2", 0.0)
                val value3 = data?.getBooleanExtra("value3", false)
                val value4 = data?.getStringExtra("value4")

                // 뽑은 data 출력
                textView.text = "value1 : ${value1}\n"
                textView.append ("value2 : ${value2}\n")        // ?) 정수만 textView.text를 쓰는 걸까? 왜 append 안쓰지?
                textView.append("value3 : ${value3}\n")
                textView.append("value4 : ${value4}")         // ?) 왜 마지막 data 출력에는 \n를 안붙이는 거지?

            }
        }
    }
}