package kr.go.mapo.myapplication

import android.os.Bundle
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import android.view.Menu
import android.view.MenuItem
import kr.go.mapo.myapplication.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding       // 바인딩 변수 만들기 (ActivityMainBinding 클래스 이미 생성)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)                    // 1)
//        setSupportActionBar(findViewById(R.id.toolbar))           // 2)
//
//        findViewById<FloatingActionButton>(R.id.fab).setOnClickListener { view ->                 // 3)
//            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                    .setAction("Action", null).show()

        // ViewBinding 으로 변경

        binding = ActivityMainBinding.inflate(layoutInflater)       // 바인딩 변수 만듬 = 클래스 인스턴스 만들어줌
        setContentView(binding.root)                                // Activity 높은 부분을 가져옴               1)
        setSupportActionBar(binding.toolbar)                        // 바인딩의 프로퍼티로 사용할 수 있음          2)

        binding.fab.setOnClickListener { view ->                    // 3)
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }
    }

    // 하단 ViewBinding으로 대체 불가능 (파인드 아이템을 사용하기 때문)
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }
    }

