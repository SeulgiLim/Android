package kr.go.mapo.myapplication

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.navigation.fragment.findNavController
import kr.go.mapo.myapplication.databinding.FragmentFirstBinding

/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class FirstFragment : Fragment() {
    // fragment에서 ViewBinding 구현 1
    private var _binding :  FragmentFirstBinding? = null     // 1) null이 들어갈 수 있는 옵셔널 형태로 _binding 변수 만들어줌
    private val binding get () = _binding!!                 //  2) 실제 사용 binding 만들어 줌


    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        // 주석처리 return inflater.inflate(R.layout.fragment_first, container, false)

        _binding = FragmentFirstBinding.inflate(inflater, container, false)             // 4) FragmentFirstBinding (class + binding 이름)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        //textview_first.text = "first fragment text"

//        textview.text = "첫번째 프레그먼트 문자"
//
//        view.findViewById<Button>(R.id.button_first).setOnClickListener {
//            findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
//        }

        binding.textview.text = "첫번째 프레그먼트 문자"
        binding.buttonFirst.setOnClickListener {                                                    // 5)
            findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
        }
    }

    override fun onDestroyView() {              // 3)
        super.onDestroyView()
        _binding = null
    }


}