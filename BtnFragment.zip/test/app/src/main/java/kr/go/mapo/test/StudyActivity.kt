package kr.go.mapo.test

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.FragmentManager
import kotlinx.android.synthetic.main.activity_study.*


class StudyActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_study)


        // 스탑워치 화면 전환 버튼
        btnST.setOnClickListener {
            val StopwatchFragment : StopwatchFragment = StopwatchFragment()
            val fragmentManager : FragmentManager = supportFragmentManager

            val fragmentTransaction = fragmentManager.beginTransaction()        // 시작
            fragmentTransaction.replace(R.id.container, StopwatchFragment)            // 할 일
            fragmentTransaction.commit()                                        // 끝
        }

        // 뽀모도로 화면 전환 버튼
        btnPM.setOnClickListener {
            val PomodoroFragment : PomodoroFragment = PomodoroFragment()
            val fragmentManager : FragmentManager = supportFragmentManager


            val fragmentTransaction = fragmentManager.beginTransaction()        // 시작
            fragmentTransaction.replace(R.id.container, PomodoroFragment)            // 할 일
            fragmentTransaction.commit()                                        // 끝
        }
    }
}